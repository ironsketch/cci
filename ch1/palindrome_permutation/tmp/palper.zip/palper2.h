#ifndef PALPER2_H
#define PALPER2_H
#include <string>
#include <iostream>
using namespace std;

void permute(string &s);
void permute(string &s, int l, int h);
void swap(string &s, int i, int j);

#endif
